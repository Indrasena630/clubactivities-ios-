<?php
include 'db.php';
// Include necessary files (stdheader.php and database.php)

// Initialize an array to store course data
$courseData = array();

// Retrieving the user ID from a query parameter
$userId = $_GET['userid']; // Change 'user_id' to the actual query parameter name
if ($_SERVER["REQUEST_METHOD"] === "GET") {
if (isset($userId)) {
    // Include your database connection logic here (replace this with your actual database connection)
    include("db.php");
    
    // Using the user ID, retrieve all the courses they studied
    $sql = "SELECT * FROM enrolatt WHERE studentid='$userId' and studentstatus = 'Approved'";
    
    // Execute the query
    $res = mysqli_query($conn, $sql);
    
    // Check the number of rows
    $count = mysqli_num_rows($res);
    
    if ($count > 0) {
        // Courses available
        while ($row = mysqli_fetch_assoc($res)) {
            $courseData[] = array(
                'ClubName' => $row['coursename'],
                'ClubCode' => $row['courseid'],
                'Status' => $row['coursestatus'],
                'Feedback' => $row['grade']
            );
        }
        $response['coursedata'] = $courseData;
        $response['status'] = true;
        $response['message'] = "Student attendance loaded Successfully";
    }
    else{
        $response['error'] = "No student found with that id number";
    }

    $conn->close();
}
else
{
    $response['error'] = "Missing requiried fields.";
}
}
else{
    $response['error'] = "Invalid request method.";
}

// Set the response header to indicate JSON content
header('Content-Type: application/json');

// Return the course data as JSON
echo json_encode($response);
?>
