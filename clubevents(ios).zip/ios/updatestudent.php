<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['name']) &&
        isset($_POST['studentid']) &&
        isset($_POST['contact']) &&
        isset($_POST['address']) 
    ) {
        $username = $_POST['name'];
        $studentid12 = $_POST['studentid'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];

        // Create SQL Query to Get the Details
        $sql = "SELECT * FROM studentdetails WHERE studentid=$studentid12";

        // Execute the Query
        $res = mysqli_query($conn, $sql);

        // Check whether the query is executed or not
        if ($res != false) {
            // Check whether the data is available or not
            $count = mysqli_num_rows($res);
            
            if ($count > 0) {
                // Create a SQL Query to Update Student Profile
                $sql = "UPDATE studentdetails SET
                        name = '$username',
                        contact = '$contact',
                        address = '$address'
                        WHERE studentid='$studentid12'";

                // Execute the Query to update the profile
                $row = mysqli_query($conn, $sql);

                if ($row != false) {
                    // Student profile edited successfully
                    $response['status'] = true;
                    $response['message'] = "Student profile edited successfully.";
                } else {
                    // Error while updating the profile
                    $response['error'] = "Error updating student profile.";
                }
            } else {
                // Student not found
                $response['error'] = "Student not found with the provided studentid.";
            }
        } else {
            // Error in executing the query
            $response['error'] = "Database query error.";
        }
    } else {
        // Missing required fields
        $response['error'] = "Missing required fields.";
    }
} else {
    // Invalid request method
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
