<?php
// Include your database connection file (db.php)
include 'db.php';

header('Content-Type: application/json');

$response = array();

// Get faculty ID from the GET request
if(isset($_GET['facultyId'])) {
    $facultyId = $_GET['facultyId'];
    
    // Query to retrieve courses assigned to the faculty member that are not completed
    $courseQuery = "SELECT courseid, coursename FROM courses WHERE facultyid='$facultyId' AND coursestatus != 'COMPLETED'";
    $courseResult = mysqli_query($conn, $courseQuery);

    if ($courseResult && mysqli_num_rows($courseResult) > 0) {
        $courses = array();

        // Fetch available courses for the faculty that are not completed
        while ($courseRow = mysqli_fetch_assoc($courseResult)) {
            $courseId = $courseRow['courseid'];
            $courseName = $courseRow['coursename'];

            $courses[] = array(
                'courseId' => $courseId,
                'courseName' => $courseName
            );
        }

        $response['success'] = true;
        $response['courses'] = $courses;
    } else {
        $response['success'] = false;
        $response['message'] = 'No active courses found for the faculty ID';
    }
} else {
    $response['success'] = false;
    $response['message'] = 'Faculty ID not provided';
}

echo json_encode($response);
?>
