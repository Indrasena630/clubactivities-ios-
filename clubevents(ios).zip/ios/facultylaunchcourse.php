<?php
// Include connection to the database
include 'db.php';

// Initialize the response array
$response = array();

// Function to handle GET requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Extract the faculty ID from the request parameters (adjust this to your method)
    $userId = $_GET['facultyId']; // You should adjust this to your actual method of extracting the faculty ID

    // Ensure the faculty ID is provided
    if (empty($userId)) {
        $response = array('message' => 'Faculty ID not provided');
        $response['status'] = false; // Include the status here
        $response['data'] = []; // Set an empty array for data
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    // Find the active course for the faculty
    $courseQuery = "SELECT * FROM courses WHERE facultyid='$userId' AND coursestatus='ACTIVE'";
    $courseResult = mysqli_query($conn, $courseQuery);
    $courseDetails = mysqli_fetch_assoc($courseResult);

    if (!$courseDetails) {
        // If no active course is found for the faculty or the course status is not active, return an error response
        $response = array('message' => 'No active course found for the faculty or the course status is not active');
        $response['status'] = false; // Include the status here
        $response['data'] = []; // Set an empty array for data
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $courseId = $courseDetails['courseid'];
    $courseStatus = $courseDetails['coursestatus'];

    if ($courseStatus === 'COMPLETED') {
        // If the course is completed, return an empty response
        $response = array('status' => false, 'message' => 'Course is completed, student details are not available');
        $response['data'] = []; // Set an empty array for data
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        // Collect student details for the active course who are approved
        $studentQuery = "SELECT e.studentid, s.name, e.studentstatus 
                        FROM enrolatt e 
                        JOIN studentdetails s ON e.studentid = s.studentid 
                        WHERE e.courseid='$courseId' AND e.studentstatus='Approved' AND e.coursestatus='ACTIVE'";
        $studentResult = mysqli_query($conn, $studentQuery);

        $studentDetails = array();

        if ($studentResult && mysqli_num_rows($studentResult) > 0) {
            while ($row = mysqli_fetch_assoc($studentResult)) {
                $studentDetails[] = array(
                    'CourseId' => $courseId,
                    'StudentId' => $row['studentid'],
                    'Name' => $row['name'],
                    'Status' => $row['studentstatus']
                );
            }

            // Assign response data
            $response['status'] = true;
            $response['message'] = 'Student details are displaying successfully.';
            $response['data'] = $studentDetails;

            // Return the student details as JSON
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            // If no students are found for the active course, return a message
            $response['status'] = false;
            $response['message'] = 'No students found for the active course';
            $response['data'] = []; // Set an empty array for data
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    }
} else {
    // If the request method is not GET, return an error response
    $response['status'] = false;
    $response['error'] = 'Invalid request method';
    $response['data'] = []; // Set an empty array for data
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
