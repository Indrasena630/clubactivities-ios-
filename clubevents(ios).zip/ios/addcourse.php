<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['eventname']) &&
        isset($_POST['eventid']) &&
        isset($_POST['sirno']) &&
        isset($_POST['totalno'])
    ) {
        $clubname = $_POST['eventname'];
        $clubid = $_POST['eventid'];
        $master = $_POST['sirno'];
        $classno = $_POST['totalno'];
        

         //1. Get the ID of Selected Admin
         

         //2. Create SQL Query to Get the Details
         $sql="SELECT * FROM facultydetails WHERE facultyid='$master'";

         //Execute the Query
         $res=mysqli_query($conn, $sql);

         //Check whether the query is executed or not
         if($res==true)
         {
        $sqq = "INSERT INTO courses SET 
        coursename = '$clubname',
        courseid = '$clubid',
        facultyid = '$master',
        strength = '$classno',
        coursestatus = 'ACTIVE'
        ";
 
        //3. Executing Query and Saving Data into Datbase
        $row = mysqli_query($conn, $sqq);
                  //4. Check whether the (Query is Executed) data is inserted or not and display appropriate message
        if($row==TRUE)
        {
            $response['status'] = true;
            $response['message'] = "course added successfully.";
        }
        else
        {
            $response['message'] = "course not add failed";
        }
        


        }
        else
        {
            $response['message'] = "Faculty is not there assign proper faculty id";
        }
        
    } 

    else {
        $response['error'] = "Missing required fields.";
    }
}
 else {
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
