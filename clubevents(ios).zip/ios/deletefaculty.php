<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['userid'])
    ) {
        $vidid = $_POST['userid'];
        

        // Replace this with your database insert logic
        // Example:
        $sql = "DELETE FROM facultydetails WHERE facultyid='$vidid'";
        $res = mysqli_query($conn, $sql);

        // Sample response for demonstration
        $response['status'] = true;
        $response['message'] = "faculty deleted successfully.";
    } 
    else {
        $response["status"] = false;
        $response['error'] = "Missing required fields.";
    }
} else {

    $response["status"] = false;
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
