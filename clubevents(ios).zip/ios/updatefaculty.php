<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['name']) &&
        isset($_POST['facultyid']) &&
        isset($_POST['contact']) &&
        isset($_POST['address']) 
    ) {
        $username = $_POST['name'];
        $facultyid = $_POST['facultyid'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];

        // Create SQL Query to Get the Details
        $sql = "SELECT * FROM facultydetails WHERE facultyid='$facultyid'"; // Enclose facultyid in single quotes

        // Execute the Query
        $res = mysqli_query($conn, $sql);

        // Check whether the query is executed or not
        if ($res != false) {
            // Check whether the data is available or not
            $count = mysqli_num_rows($res);
            
            if ($count > 0) {
                // Create a SQL Query to Update Faculty Profile
                $sql = "UPDATE facultydetails SET
                        name = '$username',
                        contact = '$contact',
                        address = '$address'
                        WHERE facultyid='$facultyid'"; // Enclose facultyid in single quotes

                // Execute the Query to update the profile
                $row = mysqli_query($conn, $sql);

                if ($row != false) {
                    // Faculty profile edited successfully
                    $response['status'] = true;
                    $response['message'] = "Faculty profile updated successfully.";
                } else {
                    // Error while updating the profile
                    $response['error'] = "Error updating faculty profile.";
                }
            } else {
                // Faculty not found
                $response['error'] = "Faculty not found with the provided facultyid.";
            }
        } else {
            // Error in executing the query
            $response['error'] = "Database query error.";
        }
    } else {
        // Missing required fields
        $response['error'] = "Missing required fields.";
    }
} else {
    // Invalid request method
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
