<?php
// Include your database connection file (db.php)
include 'db.php';

header('Content-Type: application/json');

$response = array();

// Get the selected course ID and faculty ID from the GET request
if(isset($_GET['courseId']) && isset($_GET['facultyId'])) {
    $courseId = $_GET['courseId'];
    $facultyId = $_GET['facultyId'];
    
    // Check if the selected course belongs to the faculty member
    $courseCheckQuery = "SELECT * FROM courses WHERE courseid='$courseId' AND facultyid='$facultyId'";
    $courseCheckResult = mysqli_query($conn, $courseCheckQuery);

    if ($courseCheckResult && mysqli_num_rows($courseCheckResult) > 0) {
        // Retrieve students registered for the selected course
        $studentQuery = "SELECT studentid, name FROM enrolatt WHERE courseid='$courseId'";
        $studentResult = mysqli_query($conn, $studentQuery);

        if ($studentResult && mysqli_num_rows($studentResult) > 0) {
            $students = array();

            // Fetch students registered for the selected course
            while ($studentRow = mysqli_fetch_assoc($studentResult)) {
                $studentId = $studentRow['studentid'];
                $studentName = $studentRow['name'];

                $students[] = array(
                    'studentId' => $studentId,
                    'studentName' => $studentName
                );
            }

            $response['success'] = true;
            $response['students'] = $students;
        } else {
            $response['success'] = false;
            $response['message'] = 'No students found for the selected course';
        }
    } else {
        $response['success'] = false;
        $response['message'] = 'Course not found or unauthorized access';
    }
} else {
    $response['success'] = false;
    $response['message'] = 'Course ID or Faculty ID not provided';
}

echo json_encode($response);
?>
