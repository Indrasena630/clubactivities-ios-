<?php
// Include the database connection script (e.g., db.php)
include 'db.php';

// Check if the request is a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Create an array to store API response data
    $apiResponse = array();

    // Get the course data and store it in the response array
    $sql = "SELECT * FROM courses WHERE coursestatus='ACTIVE'";
    $res = mysqli_query($conn, $sql);
    $courses = array();

    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $course = array(
                'CourseName' => $row['coursename'],
                'CourseId' => $row['courseid'],
                'Strength' => $row['strength']
            );
            $courses[] = $course;
        }
    }

    $apiResponse['courses'] = $courses;
    $apiResponse['status'] = true;
    $apiResponse['message'] = "course displayed successfully.";

    // Output the response as JSON
    header('Content-Type: application/json');
}
else {
    $apiResponse['error'] = "Invalid request method.";
}
echo json_encode($apiResponse);
?>