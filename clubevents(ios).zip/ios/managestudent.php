<?php
include 'db.php';
// Include the necessary database connection and configuration here
// For simplicity, I'll assume you have $conn and SITEURL defined

// Define the content type as JSON
header('Content-Type: application/json');

// Create an associative array to store the response data
$response = array();

// Check if the request includes a specific student ID
if (isset($_GET['id'])) {
    $studentId = $_GET['id'];
    // Query to get a specific student by ID
    $sql = "SELECT * FROM studentdetails WHERE studentid = $studentId";
    $res = mysqli_query($conn, $sql);

    if ($res && mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
        $response['student'] = $row;
        $response['success'] = true;
    } else {
        $response['error'] = 'Student not found';
    }
} else {
    // Query to get all students
    $sql = "SELECT * FROM studentdetails";
    $res = mysqli_query($conn, $sql);

    if ($res && mysqli_num_rows($res) > 0) {
        $students = array();
        while ($row = mysqli_fetch_assoc($res)) {
            $students[] = $row;
        }
        $response['students'] = $students;
        $response['success'] = true;
        $response['message'] = "Student details are displaying successfully.";
    } else {
        $response['error'] = 'No students found';
    }
}

// Return the JSON response
echo json_encode($response);
?>
