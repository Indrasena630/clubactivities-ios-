<?php
include 'db.php';

// Function to update student status
function updateStudentStatus($userId, $clubid, $status) {
    global $conn;
    $qu = "UPDATE enrolatt SET studentstatus = '$status' WHERE studentid = '$userId' AND courseid = '$clubid'";
    $res = mysqli_query($conn, $qu);

    return $res;
}

// Function to get non-rejected student details
function getStudentDetails() {
    global $conn;

    $query = "SELECT * FROM enrolatt WHERE studentstatus <> 'Rejected'";
    $result = mysqli_query($conn, $query);

    $studentDetails = array();

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $studentDetails[] = $row;
        }
    }

    return $studentDetails;
}

// Check if POST request for status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['studentid']) && isset($_POST['courseid']) && isset($_POST['studentstatus'])) {
    $userId = $_POST['studentid'];
    $clubid = $_POST['courseid'];
    $status = $_POST['studentstatus'];

    $updateResult = updateStudentStatus($userId, $clubid, $status);

    if ($updateResult) {
        $updateResponse['success'] = true;
        $updateResponse['message'] = "Student status updated successfully.";
    } else {
        $updateResponse['success'] = false;
        $updateResponse['message'] = "Failed to update student status: " . mysqli_error($conn);
    }

    echo json_encode($updateResponse);
    exit; // Stop further execution to prevent displaying HTML content below
}

// Fetch non-rejected student details
$students = getStudentDetails();

// Prepare response for student details in JSON format
if (!empty($students)) {
    $response['success'] = true;
    $response['students'] = $students;
} else {
    $response['success'] = false;
    $response['message'] = "No students found or all students are rejected.";
}

// Output response in JSON format
echo json_encode($response);
?>
