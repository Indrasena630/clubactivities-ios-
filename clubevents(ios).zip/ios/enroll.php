<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $response = array();

    if (isset($_POST['courseid']) && isset($_POST['studentid'])) {
        $studentId = $_POST['studentid'];
        $course_idd = $_POST['courseid'];

        function getCourseDetails($conn, $courseId)
        {
            $query = "SELECT * FROM courses WHERE courseid = '$courseId'";
            $response = mysqli_query($conn, $query);
            if (mysqli_num_rows($response) > 0) {
                return $response->fetch_assoc();
            }
            return false;
        }

        function getUserDetails($conn, $userId)
        {
            $query = "SELECT * FROM studentdetails WHERE studentid = '$userId'";
            $response = mysqli_query($conn, $query);
            if (mysqli_num_rows($response) > 0) {
                return $response->fetch_assoc();
            }
            return false;
        }

        $courseDetails = getCourseDetails($conn, $course_idd);
        $course_strength = $courseDetails['strength'];

        if ($course_strength > 0) {
            // Decrease the course's strength by 1 in the courses table
            $update_query = "UPDATE courses SET strength = strength - 1 WHERE courseid = '$course_idd'";
            $update_result = mysqli_query($conn, $update_query);

            if ($update_result) {
                $userDetails = getUserDetails($conn, $studentId);
                $studentname = $userDetails['name'];

                $ans = "INSERT INTO `enrolatt` (`name`, `studentid`, `courseid`, `coursename`, `studentstatus`,
                            `attendedclasses`, `totalclasses`, `coursestatus`, `grade`) 
                            VALUES ('$studentname', '$studentId', '$course_idd', '{$courseDetails['coursename']}',
                            'pending', '0', '0', 'ACTIVE', 'NA')";

                $resp = mysqli_query($conn, $ans);
                if ($resp == TRUE) {
                    $result['status'] = true;
                    $result['message'] = "Course request sent successfully";
                } else {
                    // If enrollment fails, revert the strength increment
                    $revert_query = "UPDATE courses SET strength = strength + 1 WHERE courseid = '$course_idd'";
                    mysqli_query($conn, $revert_query);

                    $result['error'] = "Failed to enroll the course";
                }
            } else {
                $result['error'] = "Failed to update course strength";
            }
        } else {
            $result['error'] = "Course is already full";
        }
    } else {
        $result['error'] = "Missing required fields.";
    }
} else {
    $result['error'] = "Invalid request method.";
}

echo json_encode($result);
?>
