<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['name']) &&
        isset($_POST['studentid']) &&
        isset($_POST['contact']) &&
        isset($_POST['address']) &&
        isset($_POST['dob']) &&
        isset($_POST['email'])
    ) {
        $username = $_POST['name'];
        $studentid = $_POST['studentid'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
        $date = $_POST['dob'];
        $email = $_POST['email'];

        // Replace this with your database insert logic
        // Example:
        $sql = "INSERT INTO studentdetails (name, studentid,password, contact, address, dob, email) VALUES ('$username', '$studentid','welcome', '$contact', '$address', '$date', '$email')";
        $res = mysqli_query($conn, $sql);

        // Sample response for demonstration
        $response['status'] = true;
        $response['message'] = "Student added successfully.";
    } 
    else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
