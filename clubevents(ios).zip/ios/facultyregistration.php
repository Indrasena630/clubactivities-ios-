<?php
include 'db.php';

$response = array();

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (isset($_GET['courseId'])) {
        $courseId = $_GET['courseId'];

        // Fetch students for the specified course
        $studentQuery = "SELECT studentid, name FROM enrolatt WHERE courseid='$courseId' AND coursestatus='ACTIVE'";
        $studentResult = mysqli_query($conn, $studentQuery);

        if ($studentResult !== false) {
            $courseStudents = array();

            if (mysqli_num_rows($studentResult) > 0) {
                while ($row = mysqli_fetch_assoc($studentResult)) {
                    $courseStudents[] = array(
                        'StudentId' => $row['studentid'],
                        'Name' => $row['name']
                    );
                }

                $response['status'] = true;
                $response['message'] = 'Student details for the course are displaying successfully.';
                $response['data'] = $courseStudents;
            } else {
                $response['status'] = true;
                $response['message'] = 'No students registered for the specified course.';
                $response['data'] = []; // Empty data array
            }
        } else {
            $response['error'] = "Query execution failed.";
        }
    } else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

// Set the response header to indicate JSON content
header('Content-Type: application/json');

// Return the course data as JSON
echo json_encode($response);
?>
