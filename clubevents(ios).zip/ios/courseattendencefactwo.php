<?php
// Include connection to the database
include 'db.php';

// Function to handle GET requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Extract the faculty ID from the URL
    $clubid = $_GET['courseId'];

    // Ensure the faculty ID is provided
    if (empty($clubid)) {
        $response = array('error' => 'Club ID not provided');
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    // Query to fetch student details for the given club ID
    $query = "SELECT * FROM enrolatt WHERE studentstatus='Approved' AND coursestatus='ACTIVE' AND courseid='$clubid'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Check if there are students found for the given club ID
        if (mysqli_num_rows($result) > 0) {
            $courses = array();

            // Loop through the retrieved student data
            while ($row = mysqli_fetch_assoc($result)) {
                // Check if totalclasses is not zero to avoid DivisionByZeroError
                $attendancePercentage = $row['totalclasses'] != 0 ? ceil(($row['attendedclasses'] / $row['totalclasses']) * 100) : 0;

                $courses[] = array(
                    'StudentId' => $row['studentid'],
                    'Name' => $row['name'],
                    'Attended Classes' => $row['attendedclasses'],
                    'Total Classes' => $row['totalclasses'],
                    'Percentage' => $attendancePercentage // Rounded attendance percentage
                );
            }

            // Return the student details for the club ID as JSON
            $response = array(
                'status' => true,
                'message' => 'Student details are displaying successfully',
                'data' => $courses
            );
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            // If no students found for the club ID, return an empty response
            $response = array(
                'status' => true,
                'message' => 'No students found for the club ID',
                'data' => [] // Return empty data
            );
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    } else {
        // Error in the query execution or connection
        $response = array(
            'status' => false,
            'message' => 'Error retrieving student details'
            // You can add more details to the error message as needed
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    }
}
?>
