<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['name']) &&
        isset($_POST['facultyid']) &&
        isset($_POST['contact']) &&
        isset($_POST['address']) &&
        isset($_POST['password']) &&
        isset($_POST['dob']) &&
        isset($_POST['email'])
    ) {
        $username = $_POST['name'];
        $facultyid12 = $_POST['facultyid'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
        $password = $_POST['password'];
        $date = $_POST['dob'];
        $email = $_POST['email'];

         //1. Get the ID of Selected Admin
         

         //2. Create SQL Query to Get the Details
         $sql="SELECT * FROM facultydetails WHERE facultyid='$facultyid12'";

         //Execute the Query
         $res=mysqli_query($conn, $sql);

         //Check whether the query is executed or not
         if($res==true)
         {
             // Check whether the data is available or not
             $count = mysqli_num_rows($res);
             //Create a SQL Query to Update Admin
        $sql = "UPDATE facultydetails SET
        name = '$username',
        contact = '$contact',
        address = '$address',
        dob = '$date',
        password='$password',
        email = '$email'
        WHERE facultyid='$facultyid12'
        ";

        //Execute the Query
        $row = mysqli_query($conn, $sql);
    
        

        // Sample response for demonstration
        $response['success'] = true;
        $response['message'] = "faculty profile updated successfully.";
        }
        else
        {
            $response['message'] = "Registration number not found";
        }
    } 
    else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
