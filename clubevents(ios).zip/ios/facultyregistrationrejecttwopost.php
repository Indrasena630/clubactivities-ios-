<?php
include 'db.php';

// Function to delete student record
function deleteStudentRecord($userId, $clubid) {
    global $conn;
    $query = "DELETE FROM enrolatt WHERE studentid = '$userId' AND courseid = '$clubid'";
    $result = mysqli_query($conn, $query);

    return $result;
}

// Check if POST request for course rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['studentid']) && isset($_POST['courseid']) && isset($_POST['studentstatus'])) {
    $userId = $_POST['studentid'];
    $clubid = $_POST['courseid'];
    $status = $_POST['studentstatus'];

    if ($status === 'Rejected') {
        $deleteResult = deleteStudentRecord($userId, $clubid);

        if ($deleteResult) {
            $response['status'] = true;
            $response['message'] = "Student rejected successfully.";
        } else {
            $response['status'] = false;
            $response['message'] = "Failed to delete student record: " . mysqli_error($conn);
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid status for deletion.";
    }

    echo json_encode($response);
    exit; // Stop further execution to prevent displaying HTML content below
}

// Fetch non-rejected student details
$query = "SELECT * FROM enrolatt WHERE studentstatus <> 'Rejected'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $students[] = $row;
    }
    $response['success'] = true;
    $response['students'] = $students;
} else {
    $response['success'] = false;
    $response['message'] = "No students found or all students are rejected.";
}

// Output response in JSON format
echo json_encode($response);
?>
