<?php
include 'db.php';

$response = array();

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (isset($_GET['courseId'])) {
        $courseId = $_GET['courseId'];

        // Fetch students for the specified course
        $studentQuery = "SELECT * FROM enrolatt WHERE courseid='$courseId' AND coursestatus='ACTIVE'";
        $studentResult = mysqli_query($conn, $studentQuery);

        if ($studentResult && mysqli_num_rows($studentResult) > 0) {
            $courseStudents = array();

            while ($row = mysqli_fetch_assoc($studentResult)) {
                $courseStudents[] = array(
                    'CourseId' => $courseId,
                    'StudentId' => $row['studentid'],
                    'Name' => $row['name'],
                    'Status' => $row['studentstatus']
                );
            }

            $response['status'] = true;
            $response['message'] = 'Student details for the course are displaying successfully.';
            $response['data'] = $courseStudents;
        } else {
            $response['error'] = "No students registered for the specified course.";
        }
    } else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

// Set the response header to indicate JSON content
header('Content-Type: application/json');

// Return the course data as JSON
echo json_encode($response);
?>
