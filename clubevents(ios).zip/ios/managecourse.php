<?php
include 'db.php';
// Include the necessary database connection and configuration here
// For simplicity, I'll assume you have $conn defined

// Define the content type as JSON
header('Content-Type: application/json');

// Create an associative array to store the response data
$response = array();

// Query to get all courses
$sql = "SELECT * FROM courses";
$res = mysqli_query($conn, $sql);

if ($res && mysqli_num_rows($res) > 0) {
    $courses = array();
    while ($row = mysqli_fetch_assoc($res)) {
        $courses[] = $row;
    }
    $response['courses'] = $courses;
    $response['status'] = true;
        $response['message'] = "course details are displaying successfully.";
} else {
    $response['error'] = 'No courses found';
}

// Return the JSON response
echo json_encode($response);
?>
