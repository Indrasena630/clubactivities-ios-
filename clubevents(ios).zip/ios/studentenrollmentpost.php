<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['courseid']) &&
        isset($_POST['studentid'])
    ) {
        $studentId=$_POST['studentid'];
        $course_idd=$_POST['courseid'];
        function getcourseDetails($conn, $user)
            {
                $query = "SELECT * FROM courses WHERE courseid = '$user'";
                $respons = mysqli_query($conn, $query);
                if(mysqli_num_rows($respons) > 0)
                {
                    return $respons->fetch_assoc();
                }
                return false;
            }
        $coursedet= getcourseDetails($conn,$course_idd);
        $course_namee=$coursedet['coursename'];
        
        function getUserDetails($conn, $user)
            {
                $query = "SELECT * FROM studentdetails WHERE studentid = '$user'";
                $response = mysqli_query($conn, $query);
                if(mysqli_num_rows($response) > 0)
                {
                    return $response->fetch_assoc();
                }
                return false;
            }
    // Get user details
    $userDetails = getUserDetails($conn, $studentId);
    $studentname=$userDetails['name'];

    //saving the data into the data base
    $ans="INSERT INTO `enrolatt` (`name`, `studentid`, `courseid`, `coursename`, `studentstatus`,
    `attendedclasses`, `totalclasses`, `coursestatus`, `grade`) 
    VALUES ('$studentname', '$studentId', '$course_idd', '$course_namee',
    'pending', '0', '0', 'ACTIVE', 'NA')";

    $resp=mysqli_query($conn,$ans);
    if($resp==TRUE)
    {
        // Sample response for demonstration
        $result['status'] = true;
        $result['message'] = "course request sent successfully";
    }
    else
    {
        $result['error'] = "Failed to enroll the course";
    }
    } 
    else {
        $result['error'] = "Missing required fields.";
    }
} else {
    $result['error'] = "Invalid request method.";
}

echo json_encode($result);
