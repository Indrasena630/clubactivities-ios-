<?php
// Include connection to the database
include 'db.php';

// Function to handle GET requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Extract the faculty ID from the URL
    $clubid = $_GET['courseId'];

    // Ensure the faculty ID is provided
    if (empty($clubid)) {
        $response = array('error' => 'Club ID not provided');
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $courses = array();

    //collect the information of all students 
    $b = "SELECT * FROM enrolatt WHERE studentstatus='Approved' AND coursestatus='ACTIVE' AND courseid='$clubid'";
    $ans = mysqli_query($conn, $b);

    if ($ans) {
        while ($row = mysqli_fetch_assoc($ans)) {
            $courses[] = array(
                'StudentId' => $row['studentid'],
                'Name' => $row['name'],
            );
        }
    }

    if (empty($courses)) {
        // If no courses are found for the faculty, return an empty response
        $response = array(
            'status' => false,
            'message' => 'No courses found for the faculty'
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Return the student details for all courses as JSON
        $response = array(
            'status' => true,
            'message' => 'Student details are displaying successfully',
            'data' => $courses
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    }
}
?>
