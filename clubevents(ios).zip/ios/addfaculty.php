<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['name']) &&
        isset($_POST['facultyid']) &&
        isset($_POST['contact']) &&
        isset($_POST['address']) &&
        isset($_POST['dob']) &&
        isset($_POST['email'])
    ) {
        $username = $_POST['name'];
        $facultyid = $_POST['facultyid'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
        $dob = $_POST['dob'];
        $email = $_POST['email'];

        // Replace this with your database insert logic
        // Example:
        $sql = "INSERT INTO facultydetails (name, facultyid,password, contact, address, dob, email) VALUES ('$username', '$facultyid','welcome', '$contact', '$address', '$dob', '$email')";
        $res = mysqli_query($conn, $sql);

        // Sample response for demonstration
        $response['status'] = true;
        $response['message'] = "Faculty added successfully.";
    } 
    else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
