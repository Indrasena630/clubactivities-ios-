<?php
include 'db.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['studentid']) && isset($_POST['courseid']) && isset($_POST['studentstatus'])) {
    $userId = $_POST['studentid'];
    $clubid = $_POST['courseid'];
    $status = $_POST['studentstatus'];
    
$qu="UPDATE enrolatt SET studentstatus = '$status'WHERE studentid = '$userId' AND courseid = '$clubid'";
$res=mysqli_query($conn,$qu);
if($res==true)
{
    $response['success'] = true;
    $response['message'] = "faculty updated successfully.";
}
else
{
    $response['message'] = "Failed to update";
}
} 
else 
{    
    $response['error'] = "Invalid request method or Missing required fields";
}
echo json_encode($response);