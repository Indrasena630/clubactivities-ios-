<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['courseid']) && isset($_POST['studentids']) && isset($_POST['grades'])) {
    $courseId = $_POST['courseid'];
    
    // Update course status to 'Completed' only for the specified course
    $ss = "UPDATE courses SET coursestatus='Completed' WHERE courseid='$courseId'";
    $conn->query($ss);

    $userIds = explode(',', $_POST['studentids']); // Convert comma-separated string to array
    $grades = explode(',', $_POST['grades']); // Convert comma-separated string to array

    $response = array(); // Initialize the response array

    if (count($userIds) === count($grades)) {
        $successCount = 0; // Count of successful updates

        // Prepare the SQL statement for updating the grades of students for the specified course
        $sql = "UPDATE enrolatt SET grade = ? WHERE studentid = ? AND courseid = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param('ssi', $grade, $userId, $courseId);

            for ($i = 0; $i < count($userIds); $i++) {
                $userId = trim($userIds[$i]);
                $grade = trim($grades[$i]);

                // Execute the prepared statement to update grades for the specific course and student
                $res = $stmt->execute();

                if ($res) {
                    $successCount++;
                }
            }

            $stmt->close();
        }
        
        if ($successCount === count($userIds)) {
            $response['status'] = true;
            $response['message'] = "Grade marked successfully";
        } else {
            $response['status'] = false;
            $response['message'] = "Failed to update grades for all students in this course.";
        }
    } else {
        $response['error'] = "Number of student IDs doesn't match the number of grades provided.";
    }
} else {
    $response['error'] = "Invalid request method or missing required fields";
}

echo json_encode($response);
?>
