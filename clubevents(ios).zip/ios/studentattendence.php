<?php
include 'db.php';

// Initialize an array to store course data
$courseData = array();
$response = array();

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (isset($_GET['id'])) {
        $userId = $_GET['id'];
    
        // Using the user ID, retrieve course data for active courses
        $sql = "SELECT * FROM enrolatt WHERE studentid='$userId' AND coursestatus='ACTIVE' AND studentstatus='Approved'";
    
        // Execute the query
        $res = mysqli_query($conn, $sql);
    
        // Check the number of rows
        $count = mysqli_num_rows($res);
    
        if ($count > 0) {
            // Courses available
            while ($row = mysqli_fetch_assoc($res)) {
                $attendedClasses = $row['attendedclasses'];
                $totalClasses = $row['totalclasses'];
                $percentage = ($totalClasses != 0) ? ceil(($attendedClasses / $totalClasses) * 100) : 100;

                $courseData[] = array(
                    'ClubName' => $row['coursename'],
                    'ClubCode' => $row['courseid'],
                    'ClassesAttended' => $row['attendedclasses'],
                    'TotalClasses' =>  $row['totalclasses'],
                    'Percentage' => $percentage
                );
            }

            $response['coursedata'] = $courseData;
            $response['status'] = true;
            $response['message'] = "Student attendance loaded Successfully";
        } else {
            // No courses found for the student, keeping course data as empty
            $response['coursedata'] = [];
            $response['status'] = true;
            $response['message'] = "No courses found for the student ID";
        }
    } else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

// Set the response header to indicate JSON content
header('Content-Type: application/json');

// Return the course data as JSON
echo json_encode($response);
?>
