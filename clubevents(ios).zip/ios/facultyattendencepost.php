<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['courseid']) && isset($_POST['studentids']) && isset($_POST['studentstatuses'])) {
    $courseId = $_POST['courseid'];
    $userIds = explode(',', $_POST['studentids']); // Convert comma-separated string to array
    $statuses = explode(',', $_POST['studentstatuses']); // Convert comma-separated string to array

    $response = array(); // Initialize the response array

    // Check if the arrays have the same length
    if (count($userIds) === count($statuses)) {
        $successCount = 0; // Count of successful updates

        // Iterate through each student
        for ($i = 0; $i < count($userIds); $i++) {
            $userId = $userIds[$i];
            $status = $statuses[$i];

            // Increment total_classes for all students
            $sql = "UPDATE enrolatt SET totalclasses = totalclasses + 1 WHERE studentid = $userId AND courseid='$courseId'";
            $res = mysqli_query($conn, $sql);

            if ($status == 'present') {
                $sq = "UPDATE enrolatt SET attendedclasses = attendedclasses + 1 WHERE studentid = $userId AND courseid='$courseId'";
                $conn->query($sq);
            }

            if ($res) {
                $successCount++;
            }
        }

        if ($successCount === count($userIds)) {
            $response['status'] = true;
            $response['message'] = "Attendance marked successfully for all students.";
        } else {
            $response['status'] = false;
            $response['message'] = "Failed to update attendance for some students.";
        }
    } else {
        $response['status'] = false;
        $response['error'] = "Arrays have different lengths.";
    }
} else {
    $response['status'] = false;
    $response['error'] = "Invalid request method or Missing required fields";
}

echo json_encode($response);
?>