<?php
// Include connection to the database
include 'db.php';

// Function to handle GET requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Extract the faculty ID from the URL
    $clubid = $_GET['courseId'];

    // Ensure the faculty ID is provided
    if (empty($clubid)) {
        $response = array('error' => 'Club ID not provided');
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $courses = array();

    //collect the information of all students 
    $b = "SELECT * FROM enrolatt WHERE studentstatus='Approved' AND coursestatus='ACTIVE' AND courseid='$clubid'";
    $ans = mysqli_query($conn, $b);

    if ($ans) {
        while ($row = mysqli_fetch_assoc($ans)) {
            $courses[] = array(
                'StudentId' => $row['studentid'],
                'Name' => $row['name'],
            );
        }
    }

    if (empty($courses)) {
        // If no students are found for the course, return an empty response with status false
        $response = array(
            'status' => false,
            'message' => 'No students found for the course',
            'data' => [] // Empty data array
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Return the student details for all courses as JSON
        $response = array(
            'status' => true,
            'message' => 'Student details are displaying successfully',
            'data' => $courses
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    }
}
?>
