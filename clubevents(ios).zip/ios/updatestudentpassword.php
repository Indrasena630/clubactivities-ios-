<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (
        isset($_POST['studentid']) &&
        isset($_POST['password']) &&
        isset($_POST['confirmpassword'])
    ) {
        $userid = $_POST['studentid'];
        $onepass = $_POST['password'];
        $twopass = $_POST['confirmpassword'];
        

         //1. Get the ID of Selected Admin
         

         //2. Create SQL Query to Get the Details
         $sql="SELECT * FROM studentdetails WHERE studentid=$userid";

         //Execute the Query
         $res=mysqli_query($conn, $sql);

         //Check whether the query is executed or not
         if($res==true)
         {
            if($onepass==$twopass)
            {
                //Update the Password
                $sql2 = "UPDATE studentdetails SET 
                    password='$onepass' 
                    WHERE studentid=$userid
                ";

                //Execute the Query
                $res2 = mysqli_query($conn, $sql2);

                //CHeck whether the query exeuted or not
                if($res2==true)
                {
                    $response['status'] = true;
                    $response['message'] = "Password changed successfully.";
                }
                else
                {
                    $response['message'] = "failed to update";
                }
            }
            else{
                $response['message'] = "password and confirm need to be same";
            }
        }
        else
        {
            $response['message'] = "Registration number not found";
        
    } 
}
    else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
