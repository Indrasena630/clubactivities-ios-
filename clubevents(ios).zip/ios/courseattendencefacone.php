<?php
// Include your database connection file (db.php)
include 'db.php';

header('Content-Type: application/json');

$response = array();

// Get faculty ID from the GET request
if(isset($_GET['facultyId'])) {
    $facultyId = $_GET['facultyId'];
    
    // Query to retrieve courses assigned to the faculty member that are not completed
    $courseQuery = "SELECT courseid, coursename FROM courses WHERE facultyid='$facultyId' AND coursestatus != 'COMPLETED'";
    $courseResult = mysqli_query($conn, $courseQuery);

    if ($courseResult !== false && mysqli_num_rows($courseResult) > 0) {
        $courses = array();

        // Fetch available courses for the faculty that are not completed
        while ($courseRow = mysqli_fetch_assoc($courseResult)) {
            $courseId = $courseRow['courseid'];
            $courseName = $courseRow['coursename'];

            $courses[] = array(
                'courseId' => $courseId,
                'courseName' => $courseName
            );
        }

        $response['status'] = true;
        $response['message'] = 'Active courses found for the faculty ID';
        $response['courses'] = $courses;
    } else {
        // No courses found or query error, setting empty array for courses
        $response['status'] = false;
        $response['message'] = 'No active courses found for the faculty ID';
        $response['courses'] = [];
    }
} else {
    $response['status'] = false;
    $response['message'] = 'Faculty ID not provided';
}

echo json_encode($response, JSON_PRETTY_PRINT);
?>
